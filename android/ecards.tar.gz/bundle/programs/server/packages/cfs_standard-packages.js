(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cfs:standard-packages'] = {};

})();

//# sourceMappingURL=cfs_standard-packages.js.map
